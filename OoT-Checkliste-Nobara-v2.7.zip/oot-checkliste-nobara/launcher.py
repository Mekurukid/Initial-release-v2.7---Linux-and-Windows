#!/usr/bin/env python3
"""Isolated system-Python bootstrap with visible CLI/desktop failures."""
import contextlib
import io
import os
from pathlib import Path
import sys
import traceback

ROOT=Path(__file__).resolve().parent
# -I deliberately removes the script directory. Add only our own trusted files.
sys.path.insert(0,str(ROOT))

class Tee:
    def __init__(self,stream,capture):self.stream=stream;self.capture=capture
    def write(self,text):
        self.capture.write(text)
        if self.stream:
            try:self.stream.write(text);self.stream.flush()
            except (OSError,ValueError):pass
        return len(text)
    def flush(self):
        if self.stream:
            try:self.stream.flush()
            except (OSError,ValueError):pass

def write_private(path,text):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(fd,'w',encoding='utf-8') as stream:stream.write(text)
    path.chmod(0o600)

def main():
    if sys.version_info<(3,8):
        print('Python 3.8 oder neuer wird benoetigt. Auf Nobara: sudo dnf install python3',file=sys.stderr)
        return 1
    if hasattr(os,'geteuid') and os.geteuid()==0 and os.environ.get('OOT_ALLOW_ROOT')!='1':
        print('Bitte OHNE sudo und NICHT als root starten. Deine Checkliste gehoert in dein normales Benutzerkonto.',file=sys.stderr)
        return 1
    capture=io.StringIO();code=1;support=None;report_path=None
    gui='--desktop' in sys.argv or os.environ.get('OOT_GUI')=='1'
    try:
        import desktop_support as support
        # The daemon already has a separate private server log and no dialogs.
        if '--serve' in sys.argv:
            import app
            return app.main()
        with contextlib.redirect_stdout(Tee(sys.stdout,capture)),contextlib.redirect_stderr(Tee(sys.stderr,capture)):
            import app
            code=app.main() or 0
    except KeyboardInterrupt:
        code=130;capture.write('Durch Benutzer abgebrochen.\n')
    except Exception:
        message='Die OoT-App konnte nicht gestartet werden.\n'+traceback.format_exc()
        print(message,file=sys.stderr);capture.write(message);code=1
        # Compatibility with the previous troubleshooting instructions.
        try:write_private(ROOT/'OoT-START-FEHLER.txt',support.redact(message) if support else message)
        except OSError:pass
    text=capture.getvalue()
    if support:
        try:
            report_path=support.log_directory()/'letzter-start.log'
            write_private(report_path,support.redact(text) or 'Start erfolgreich.\n')
        except OSError:report_path=None
        if gui:
            if '--diagnose' in sys.argv:
                try:
                    import app
                    path=app.data_folder()/'OoT-Nobara-Diagnose.txt'
                    support.dialog('OoT - Nobara Startdiagnose',text,error=bool(code),report=path if path.exists() else report_path)
                except Exception:pass
            elif code and code!=130:
                # Show the working URL in the dialog when browser handoff failed;
                # stored diagnostics redact session tokens.
                message=text[-6500:]+'\n\nBitte die Meldung lesen. Keine Sicherheitseinstellungen aendern.'
                if report_path:message+='\nDiagnose-Protokoll: '+str(report_path)
                shown=support.dialog('OoT - Start konnte nicht abgeschlossen werden',message,error=True,report=None)
                if not shown and report_path:
                    support.dialog('OoT - Startprotokoll',message,error=True,report=report_path)
            elif '--install' in sys.argv:
                support.dialog('OoT installiert','Du findest OoT Sammel-Checklisten jetzt im App-Menue. Dein gespeicherter Fortschritt bleibt erhalten.')
    if code and report_path:print('Startprotokoll:',report_path,file=sys.stderr)
    return code

if __name__=='__main__':
    raise SystemExit(main())
