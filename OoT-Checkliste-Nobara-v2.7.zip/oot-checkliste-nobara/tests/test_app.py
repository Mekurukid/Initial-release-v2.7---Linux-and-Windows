"""Offline regression tests. Fixtures use invented text, not copied guide prose."""
import copy
import html
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
import urllib.error

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import app
from guide_reader import Page,decode_page,parse_guide,safe_url
PNG=b'\x89PNG\r\n\x1a\n'+b'test fixture, not an actual screenshot'

def fixture(cat_id):
 c=next(c for c in app.CATEGORIES if c['id']==cat_id)
 items=[i for i in app.BASE if i['category']==cat_id]
 parts=['<html><head><script>Never execute this</script></head><body>']
 if cat_id=='skulltula':
  groups={}
  for i in items:groups.setdefault(i['region'],[]).append(i)
  for region,entries in groups.items():
   parts.append('<p><b>&raquo; '+html.escape(region)+' ['+str(len(entries))+' Goldene Skulltula'+('s' if len(entries)>1 else '')+'] &laquo;</b></p><ul>')
   for i in entries:parts.append('<li>Testfundort '+str(i['number'])+' mit einer frei erfundenen Beschreibung.</li>')
   parts.append('</ul>')
   for i in entries:parts.append('<img src="'+i['images'][0]+'">')
 else:
  for i in items:
   title=html.escape(i['source_title'])
   if cat_id=='upgrades':
    if i['number'] in range(10,20):title='Upgrade: '+html.escape(i['title'].split(' (')[0])+' tragen'
    else:title='Die '+title
    heading='&raquo; '+title+' &laquo;'
   elif cat_id=='feen':heading='&raquo; '+('Gro\u00dfe Fee bei ' if i['number']<=6 else str(i['number']-6)+'. Feenquelle: ')+title+' &laquo;'
   elif cat_id=='songs':heading=title
   elif cat_id=='flaschen':heading=str(i['number'])+'. Flasche: '+title
   else:heading=str(i['number'])+'. '+title
   parts.append('<table><tr><td><b>'+heading+'</b><br>')
   if cat_id=='herzen':parts.append('Erreichbar als: '+html.escape(i['age'])+'<br>')
   parts.append('Testbeschreibung '+str(i['number'])+'. Dieser Fundorttext dient nur zur Funktionspr\u00fcfung.')
   if cat_id=='flaschen' and i['number']==3:
    for k in range(1,8):parts.append('<p>'+str(k)+'. Huhn als absichtlicher Testunterpunkt.</p>')
   parts.append('</td><td>')
   for u in i['images']:parts.append('<img src="'+u+'" width="238">')
   parts.append('</td></tr></table>')
 parts.append('<footer>Projekt Zelda Europe</footer></body></html>')
 return ''.join(parts)

class StateTests(unittest.TestCase):
 def setUp(self):self.temp=tempfile.TemporaryDirectory();self.path=Path(self.temp.name);self.store=app.Store(self.path,False)
 def tearDown(self):self.temp.cleanup()
 def test_counts(self):
  self.assertEqual(len(app.BASE),224);self.assertEqual(len(app.IDS),224)
  for c in app.CATEGORIES:self.assertEqual(sum(i['category']==c['id'] for i in app.BASE),c['count'])
 def test_save_and_restart(self):
  for i in ('herzen:001','skulltula:100','upgrades:023'):self.store.mutate('check',dict(id=i,checked=True))
  self.store.mutate('note',dict(id='songs:001',note='Sp\u00e4ter suchen. \u2665'))
  new=app.Store(self.path,False);self.assertEqual(len(new.state['checked']),3);self.assertEqual(new.state['notes']['songs:001'],'Sp\u00e4ter suchen. \u2665')
 def test_migrate_old_state_and_image(self):
  old=dict(app='oot-herzteil-checkliste',version=1,checked=[1,36],notes={'1':'Alte Notiz'})
  app.atomic_json(self.path/'fortschritt.json',old);app.atomic_bytes(self.path/'bilder'/'01.img',PNG)
  new=app.Store(self.path,False);self.assertEqual(new.state['checked'],['herzen:001','herzen:036']);self.assertEqual(new.state['notes']['herzen:001'],'Alte Notiz');self.assertTrue(new.migrated)
  self.assertEqual(json.loads((self.path/'fortschritt.json').read_text()),old);self.assertTrue((self.path/'herzteile-v1-vor-update.json').exists());self.assertEqual(len(new.cached),1)
  self.assertEqual(app.Store(self.path,False).state['checked'],['herzen:001','herzen:036'])
 def test_migrate_old_guide(self):
  old=[dict(id=i,description='Alte Beschreibung '+str(i)) for i in range(1,37)]
  app.atomic_json(self.path/'vorlage.json',dict(items=old));s=app.Store(self.path,False)
  self.assertTrue(s.guides['herzen']['loaded']);self.assertEqual(s.items[0]['description'],'Alte Beschreibung 1')
 def test_v1_import_only_hearts(self):
  for i in ('skulltula:004','herzen:003'):self.store.mutate('check',dict(id=i,checked=True));self.store.mutate('note',dict(id=i,note='Behalten'))
  old=dict(app='oot-herzteil-checkliste',version=1,checked=[9],notes={'9':'Importiert'})
  self.store.mutate('import',dict(state=old));s=self.store.snapshot();self.assertEqual(s['checked'],['herzen:009','skulltula:004']);self.assertIn('skulltula:004',s['notes']);self.assertNotIn('herzen:003',s['notes'])
 def test_reset_scope_notes_backups(self):
  for i in ('skulltula:001','herzen:001'):self.store.mutate('check',dict(id=i,checked=True));self.store.mutate('note',dict(id=i,note='Notiz'))
  self.store.mutate('reset',dict(category='herzen'));self.assertEqual(self.store.state['checked'],['skulltula:001']);self.assertEqual(len(self.store.state['notes']),2);self.assertEqual(len(list(self.path.glob('sicherung-v2-*.json'))),1)
 def test_invalid_ids_and_values(self):
  for i in ('herzen:037','skulltula:101',1,True,None):
   with self.assertRaises(ValueError):self.store.mutate('check',dict(id=i,checked=True))
  with self.assertRaises(ValueError):self.store.mutate('check',dict(id='herzen:001',checked='true'))
  with self.assertRaises(ValueError):self.store.mutate('note',dict(id='herzen:001',note='x'*2001))
 def test_invalid_imports(self):
  for raw in ({},[],dict(app='other',version=2),dict(app='oot-sammel-checklisten',version=2,checked=['herzen:001']*2),dict(app='oot-herzteil-checkliste',version=1,checked=[True])):
   with self.assertRaises(ValueError):self.store.mutate('import',dict(state=raw))
 def test_failed_write_preserves_memory(self):
  with patch.object(app,'atomic_json',side_effect=OSError('Disk full')):
   with self.assertRaises(OSError):self.store.mutate('check',dict(id='herzen:001',checked=True))
  self.assertEqual(self.store.state['checked'],[])
 def test_corrupt_recovery(self):
  self.store.mutate('check',dict(id='herzen:001',checked=True));self.store.mutate('check',dict(id='herzen:002',checked=True));self.store.path.write_text('BROKEN')
  s=app.Store(self.path,False);self.assertEqual(s.state['checked'],['herzen:001']);self.assertTrue(s.warning);self.assertTrue(list(self.path.glob('fortschritt-v2-beschaedigt-*.json')))
 def test_concurrent_changes(self):
  ts=[threading.Thread(target=self.store.mutate,args=('check',dict(id=i['id'],checked=True))) for i in app.BASE[:48]]
  for t in ts:t.start()
  for t in ts:t.join()
  self.assertEqual(len(self.store.state['checked']),48)
 def test_html_import_preserves_state(self):
  self.store.mutate('check',dict(id='herzen:001',checked=True));self.store.import_html('herzen',fixture('herzen'));self.assertEqual(self.store.state['checked'],['herzen:001']);self.assertTrue(self.store.guides['herzen']['loaded']);self.assertTrue(app.Store(self.path,False).guides['herzen']['loaded'])
 def test_download_failure_safe(self):
  self.store.mutate('check',dict(id='skulltula:100',checked=True))
  with patch.object(app,'download',side_effect=urllib.error.URLError('offline')):
   self.store.refresh()
   for _ in range(300):
    if not self.store.refreshing:break
    time.sleep(.01)
  self.assertFalse(self.store.refreshing);self.assertTrue(self.store.job_error);self.assertEqual(self.store.state['checked'],['skulltula:100'])
 def test_mocked_download_all(self):
  sources={c['source']:fixture(c['id']).encode() for c in app.CATEGORIES}
  with patch.object(app,'download',side_effect=lambda u:(sources.get(u,PNG),'utf-8')):
   self.store.refresh()
   for _ in range(500):
    if not self.store.refreshing:break
    time.sleep(.01)
  self.assertFalse(self.store.refreshing);self.assertTrue(all(g['loaded'] for g in self.store.guides.values()));self.assertEqual(len(self.store.cached),len(self.store.urls));self.assertFalse(self.store.job_error)

class ParserTests(unittest.TestCase):
 def test_ten_templates(self):
  for c in app.CATEGORIES:
   with self.subTest(category=c['id']):
    base=[i for i in app.BASE if i['category']==c['id']];out=parse_guide(c,fixture(c['id']),base)
    self.assertEqual([i['id'] for i in out],[i['id'] for i in base]);self.assertTrue(all(len(i['description'])>=8 for i in out));self.assertFalse(any('Never execute' in i['description'] for i in out))
 def test_incomplete_rejected(self):
  c=app.CATEGORIES[0]
  with self.assertRaises(ValueError):parse_guide(c,'<b>1. Missing sections</b>',app.BASE[:36])
 def test_thumb_vs_actual_25a(self):
  p=Page('https://zeldachronicles.de/spiele/oot/upgrades.php');p.feed('<img width="238" src="guide/upgrades/oot_ausruestung_25a.jpg"><img width="65" src="guide/upgrades/oot_ausruestung_34a.jpg">')
  self.assertTrue(p.images[0].endswith('_25a.jpg'));self.assertTrue(p.images[1].endswith('_34.jpg'))
 def test_host_safety(self):
  for u in ('file:///etc/passwd','http://127.0.0.1/foo','https://example.com/a','https://zeldachronicles.de.evil.org/foo','https://u:p@zeldachronicles.de/foo'):
   with self.assertRaises(ValueError):safe_url(u)
 def test_encodings(self):
  s='Gro\u00dfe Feen und R\u00fcstungen'
  for enc in ('utf-8','cp1252'):self.assertEqual(decode_page(s.encode(enc)),s)

if __name__=='__main__':unittest.main(verbosity=2)
