"""Offline launch regressions: real subprocesses and loopback HTTP; no browser needed."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import app

class LaunchTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='oot-launch-')
        self.base=Path(self.temp.name);self.data=self.base/'data'
        self.env=dict(os.environ,OOT_CHECKLIST_DATA_DIR=str(self.data),OOT_NO_PAUSE='1',XDG_DATA_HOME=str(self.base/'data home'))
        for key in ('BROWSER','DISPLAY','WAYLAND_DISPLAY'):self.env.pop(key,None)
    def tearDown(self):
        app.stop_running(self.data);self.temp.cleanup()
    def launch(self,*flags,root=ROOT):
        return subprocess.run(['/bin/sh',str(root/'STARTEN.sh'),*flags],env=self.env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=18)
    def api(self,path,data=None):
        live=app.running(self.data);self.assertIsNotNone(live)
        request=urllib.request.Request(live[0]+'api/'+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=5) as response:return json.load(response)
    def test_start_reuse_restart_and_storage(self):
        first=self.launch('--no-download','--no-browser');self.assertEqual(first.returncode,0,first.stdout)
        self.assertEqual(self.api('ping')['version'],'2.7.0');self.assertEqual(len(self.api('guide')['items']),224)
        meta=json.loads((self.data/'laufend.json').read_text())
        second=self.launch('--no-download','--no-browser');self.assertEqual(second.returncode,0,second.stdout)
        self.assertEqual(json.loads((self.data/'laufend.json').read_text())['pid'],meta['pid'])
        self.api('check',{'id':'herzen:003','checked':True});self.api('note',{'id':'herzen:003','note':'Neustart-Test'})
        restarted=self.launch('--restart','--no-download','--no-browser');self.assertEqual(restarted.returncode,0,restarted.stdout)
        saved=self.api('state')['state'];self.assertEqual(saved['checked'],['herzen:003']);self.assertEqual(saved['notes']['herzen:003'],'Neustart-Test')
    def test_old_version_stays_running_until_explicit_restart(self):
        process=subprocess.Popen([sys.executable,'-c',"import app; app.VERSION='2.0.0'; app.serve(app.data_folder(),True)"],env=self.env,cwd=ROOT,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        try:
            for _ in range(50):
                if app.running(self.data):break
                time.sleep(.1)
            self.assertEqual(app.running(self.data)[1],'2.0.0')
            self.api('check',{'id':'skulltula:100','checked':True})
            blocked=self.launch('--no-browser','--no-download')
            self.assertEqual(blocked.returncode,2,blocked.stdout);self.assertIn('Eine andere App-Version',blocked.stdout)
            self.assertIsNone(process.poll())
            restarted=self.launch('--restart','--no-browser','--no-download')
            self.assertEqual(restarted.returncode,0,restarted.stdout)
            self.assertEqual(app.running(self.data)[1],'2.7.0')
            self.assertEqual(self.api('state')['state']['checked'],['skulltula:100'])
        finally:
            if process.poll() is None:
                app.stop_running(self.data)
                try:process.wait(timeout=3)
                except subprocess.TimeoutExpired:process.terminate();process.wait(timeout=3)
    def test_missing_browser_visible_fallback(self):
        result=self.launch('--no-download');self.assertEqual(result.returncode,3,result.stdout)
        self.assertIn('konnte nicht automatisch',result.stdout);self.assertIsNotNone(app.running(self.data))
        self.assertTrue((ROOT/'APP_IM_BROWSER.html').is_file())
    def test_incomplete_archive(self):
        incomplete=self.base/'partial';incomplete.mkdir();shutil.copy2(ROOT/'STARTEN.sh',incomplete/'STARTEN.sh')
        result=self.launch('--no-browser',root=incomplete);self.assertEqual(result.returncode,1);self.assertIn('Datei fehlt: launcher.py',result.stdout)
    def test_server_failure_is_reported(self):
        self.data.mkdir();(self.data/'fortschritt-v2.json').mkdir()
        result=self.launch('--no-browser','--no-download');self.assertEqual(result.returncode,1,result.stdout)
        self.assertIn('Start fehlgeschlagen',result.stdout);self.assertIn('Is a directory',result.stdout)
        self.assertTrue((self.data/'fortschritt-v2.json').is_dir())
    def test_install_path_with_spaces(self):
        result=self.launch('--install');self.assertEqual(result.returncode,0,result.stdout)
        base=Path(self.env['XDG_DATA_HOME']);target=base/'oot-herzteil-checkliste-programm'
        desktop=(base/'applications'/'oot-herzteil-checkliste.desktop').read_text()
        self.assertIn('Terminal=false',desktop);self.assertIn('STARTEN.sh',desktop)
        for name in ('launcher.py','DIREKTSTART.html','DIAGNOSE.sh'):self.assertTrue((target/name).is_file(),name)
        result=self.launch('--no-browser','--no-download',root=target);self.assertEqual(result.returncode,0,result.stdout)
    def test_diagnosis_no_state_or_token(self):
        self.assertEqual(self.launch('--no-browser','--no-download').returncode,0)
        self.api('note',{'id':'songs:001','note':'PRIVATE_NOTE_TEST'})
        token=json.loads((self.data/'laufend.json').read_text())['token']
        result=self.launch('--diagnose');self.assertEqual(result.returncode,0,result.stdout)
        self.assertIn('Schreibtest: OK',result.stdout);self.assertNotIn(token,result.stdout);self.assertNotIn('PRIVATE_NOTE_TEST',result.stdout)
    def test_import_failure_report(self):
        broken=self.base/'broken';shutil.copytree(ROOT,broken,ignore=shutil.ignore_patterns('__pycache__','APP_IM_BROWSER.html'))
        (broken/'catalog.json').write_text('INVALID JSON')
        result=self.launch('--no-browser',root=broken);self.assertEqual(result.returncode,1,result.stdout)
        self.assertIn('JSONDecodeError',result.stdout);self.assertTrue((broken/'OoT-START-FEHLER.txt').is_file())

if __name__=='__main__':unittest.main()
