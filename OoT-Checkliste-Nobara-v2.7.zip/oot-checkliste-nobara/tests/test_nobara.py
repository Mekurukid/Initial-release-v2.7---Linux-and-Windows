"""Nobara-specific integration tests; desktop helpers are mocked, not a real KDE session."""
import copy
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import app
import desktop_support as desktop

URL='http://127.0.0.1:54321/'+'a'*48+'/'

class DesktopTests(unittest.TestCase):
    def test_nobara_detection(self):
        with patch.object(desktop,'os_release',return_value={'ID':'nobara','PRETTY_NAME':'Nobara Linux'}),patch.dict(os.environ,{'XDG_CURRENT_DESKTOP':'KDE','XDG_SESSION_TYPE':'wayland'},clear=True):
            info=desktop.system_summary();self.assertTrue(info['nobara']);self.assertEqual(info['session'],'wayland')
    def test_relative_xdg_ignored(self):
        with patch.dict(os.environ,{'XDG_DATA_HOME':'relative-path'}):
            self.assertEqual(desktop.install_target(),Path.home()/'.local/share/oot-herzteil-checkliste-programm')
    def test_kde_default_first(self):
        with patch.dict(os.environ,{'WAYLAND_DISPLAY':'wayland-0','XDG_CURRENT_DESKTOP':'KDE'},clear=True),patch.object(desktop.shutil,'which',side_effect=lambda x:'/mock/'+x),patch.object(desktop,'_command_ok',return_value=True) as run:
            self.assertTrue(desktop.open_browser(URL));self.assertEqual(run.call_args[0][0],['/mock/xdg-open',URL])
    def test_gnome_default_first(self):
        with patch.dict(os.environ,{'WAYLAND_DISPLAY':'wayland-0','XDG_CURRENT_DESKTOP':'GNOME'},clear=True),patch.object(desktop.shutil,'which',side_effect=lambda x:'/mock/'+x),patch.object(desktop,'_command_ok',return_value=True) as run:
            self.assertTrue(desktop.open_browser(URL));self.assertEqual(run.call_args[0][0],['/mock/gio','open',URL])
    def test_native_browser_fallback(self):
        with patch.dict(os.environ,{'WAYLAND_DISPLAY':'wayland-0'},clear=True),patch.object(desktop.shutil,'which',side_effect=lambda x:'/mock/firefox' if x=='firefox' else None),patch.object(desktop,'_command_ok',return_value=True) as run:
            self.assertTrue(desktop.open_browser(URL));self.assertEqual(run.call_args[0][0],['/mock/firefox',URL])
    def test_flatpak_browser_fallback(self):
        with patch.dict(os.environ,{'WAYLAND_DISPLAY':'wayland-0'},clear=True),patch.object(desktop.shutil,'which',side_effect=lambda x:'/mock/flatpak' if x=='flatpak' else None),patch.object(desktop.subprocess,'run',return_value=subprocess.CompletedProcess([],0)),patch.object(desktop,'_command_ok',return_value=True) as run:
            self.assertTrue(desktop.open_browser(URL));self.assertEqual(run.call_args[0][0],['/mock/flatpak','run','org.mozilla.firefox',URL])
    def test_no_graphical_session_no_blind_spawn(self):
        with patch.dict(os.environ,{},clear=True),patch.object(desktop,'_command_ok') as run:
            self.assertFalse(desktop.open_browser(URL));run.assert_not_called()
    def test_url_validation(self):
        for url in ('file:///etc/passwd','https://example.com/',URL+'api/shutdown','http://127.0.0.1:42/not-a-token/'):
            with self.assertRaises(ValueError):desktop.open_browser(url)
    def test_environment_sanitized_session_kept(self):
        env={'PYTHONHOME':'bad','QT_PLUGIN_PATH':'bad','LD_PRELOAD':'bad','WAYLAND_DISPLAY':'wayland-0','DBUS_SESSION_BUS_ADDRESS':'unix:session','XDG_ACTIVATION_TOKEN':'window-token'}
        with patch.dict(os.environ,env,clear=True):
            clean=desktop.desktop_environment()
            self.assertNotIn('PYTHONHOME',clean);self.assertNotIn('QT_PLUGIN_PATH',clean);self.assertNotIn('LD_PRELOAD',clean)
            self.assertEqual(clean['DBUS_SESSION_BUS_ADDRESS'],'unix:session');self.assertEqual(clean['XDG_ACTIVATION_TOKEN'],'window-token')
    def test_diagnostics_redact_token_and_home(self):
        out=desktop.redact(URL+' '+str(Path.home())+'/files')
        self.assertNotIn('a'*48,out);self.assertNotIn(str(Path.home()),out)
    def test_os_release_not_executed(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'os-release';p.write_text('ID=nobara\nPRETTY_NAME="Nobara Linux"\nBOGUS=$(touch /tmp/NEVER)\n')
            self.assertEqual(desktop.os_release(p)['ID'],'nobara')
            self.assertEqual(desktop.os_release(p)['PRETTY_NAME'],'Nobara Linux')
    def test_kdialog_error_used_on_wayland(self):
        with patch.dict(os.environ,{'WAYLAND_DISPLAY':'wayland-0'},clear=True),patch.object(desktop.shutil,'which',side_effect=lambda x:'/mock/kdialog' if x=='kdialog' else None),patch.object(desktop.subprocess,'run',return_value=subprocess.CompletedProcess([],0)) as run:
            self.assertTrue(desktop.dialog('Start','A < B',error=True))
            command=run.call_args[0][0];self.assertIn('--error',command);self.assertIn('A &lt; B',command)

class NobaraInstallTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='oot-nobara-tests-')
        self.base=Path(self.temp.name);self.data=self.base/'saves'
        self.env=dict(os.environ,OOT_ALLOW_ROOT='1',OOT_GUI='0',OOT_NO_PAUSE='1',
                      OOT_CHECKLIST_DATA_DIR=str(self.data),XDG_DATA_HOME=str(self.base/'Nobara Daten'),
                      XDG_STATE_HOME=str(self.base/'state'))
        for k in ('BROWSER','DISPLAY','WAYLAND_DISPLAY'):self.env.pop(k,None)
    def tearDown(self):app.stop_running(self.data);self.temp.cleanup()
    def launch(self,*flags,root=ROOT,env=None):
        return subprocess.run(['/bin/sh',str(root/'STARTEN.sh'),*flags],env=env or self.env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=25)
    def api(self,route,data=None):
        live=app.running(self.data);self.assertIsNotNone(live)
        req=urllib.request.Request(live[0]+'api/'+route,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=5) as response:return json.load(response)
    def test_install_and_start_from_installed_copy(self):
        result=self.launch('--install-start','--no-download','--no-browser');self.assertEqual(result.returncode,0,result.stdout)
        self.assertEqual(self.api('ping')['version'],'2.7.0')
        text=self.api('diagnostic')['report'];self.assertIn('oot-herzteil-checkliste-programm',text)
        self.assertEqual(len(self.api('guide')['items']),224)
    def test_v21_save_retained_and_backed_up(self):
        self.data.mkdir();state=app.empty_state();state['checked']=['herzen:003','skulltula:100'];state['notes']={'songs:012':'Saved before Nobara'}
        app.atomic_json(self.data/'fortschritt-v2.json',state)
        original=(self.data/'fortschritt-v2.json').read_bytes()
        result=self.launch('--install-start','--no-download','--no-browser');self.assertEqual(result.returncode,0,result.stdout)
        self.assertEqual(self.api('state')['state']['checked'],state['checked'])
        self.assertEqual(self.api('state')['state']['notes'],state['notes'])
        backups=list(self.data.glob('fortschritt-v2-vor-nobara-*.json'));self.assertEqual(len(backups),1);self.assertEqual(backups[0].read_bytes(),original)
    def test_poisoned_python_environment_ignored(self):
        env=dict(self.env,PYTHONHOME='/definitely-missing-python',PYTHONPATH='/bad/package/path')
        result=self.launch('--no-download','--no-browser',env=env);self.assertEqual(result.returncode,0,result.stdout)
        self.assertEqual(self.api('ping')['version'],'2.7.0')
    def test_launcher_from_arbitrary_working_directory(self):
        result=subprocess.run(['/bin/sh',str(ROOT/'STARTEN.sh'),'--no-download','--no-browser'],cwd='/',env=self.env,capture_output=True,text=True,timeout=20)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
    def test_system_and_diagnostic_routes_no_secrets(self):
        self.assertEqual(self.launch('--no-download','--no-browser').returncode,0)
        self.api('note',{'id':'songs:001','note':'VERY_PRIVATE_TEST'})
        token=json.loads((self.data/'laufend.json').read_text())['token']
        info=self.api('system');self.assertEqual(info['edition'],'Nobara Edition 2.7')
        report=self.api('diagnostic')['report'];self.assertNotIn(token,report);self.assertNotIn('VERY_PRIVATE_TEST',report)
    def test_install_rollback_keeps_previous(self):
        with patch.dict(os.environ,self.env,clear=True),patch.object(desktop.shutil,'which',return_value=None):
            target=desktop.install_target();target.mkdir(parents=True);(target/'previous.txt').write_text('KEEP')
            actual=app.atomic_bytes;failed=[False]
            def maybe_fail(path,data):
                if str(path).endswith('.desktop') and not failed[0]:failed[0]=True;raise OSError('simulated disk full')
                return actual(path,data)
            with patch.object(app,'atomic_bytes',side_effect=maybe_fail):
                with self.assertRaises(OSError):desktop.install_app(app)
            self.assertEqual((target/'previous.txt').read_text(),'KEEP');self.assertFalse((target/'app.py').exists())
    def test_reinstall_keeps_previous_program(self):
        self.assertEqual(self.launch('--install').returncode,0)
        target=Path(self.env['XDG_DATA_HOME'])/'oot-herzteil-checkliste-programm'
        (target/'before-update.txt').write_text('OLD')
        self.assertEqual(self.launch('--install').returncode,0)
        previous=list(target.parent.glob('.oot-vor-nobara-*'));self.assertEqual(len(previous),1)
        self.assertEqual((previous[0]/'before-update.txt').read_text(),'OLD')
    @unittest.skipUnless(hasattr(os,'geteuid') and os.geteuid()==0,'Root refusal only testable as root')
    def test_root_refused_by_default(self):
        env=dict(self.env);env.pop('OOT_ALLOW_ROOT')
        result=self.launch('--install',env=env);self.assertEqual(result.returncode,1);self.assertIn('OHNE sudo',result.stdout)
    def test_private_metadata_and_log_permissions(self):
        self.assertEqual(self.launch('--no-download','--no-browser').returncode,0)
        path=self.data/'laufend.json';token=json.loads(path.read_text())['token']
        self.assertEqual(path.stat().st_mode&0o777,0o600)
        log=Path(self.env['XDG_STATE_HOME'])/'oot-checklisten/letzter-start.log'
        self.assertEqual(log.stat().st_mode&0o777,0o600);self.assertNotIn(token,log.read_text())
    def test_stop_keeps_saved_check(self):
        self.assertEqual(self.launch('--no-download','--no-browser').returncode,0)
        self.api('check',{'id':'skulltula:001','checked':True})
        self.assertEqual(self.launch('--stop').returncode,0);self.assertIsNone(app.running(self.data))
        self.assertEqual(json.loads((self.data/'fortschritt-v2.json').read_text())['checked'],['skulltula:001'])

if __name__=='__main__':unittest.main()
