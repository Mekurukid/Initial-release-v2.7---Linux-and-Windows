#!/usr/bin/env python3
"""OoT Sammel-Checklisten 2.7 Nobara. Local Linux application; Python stdlib only."""
from __future__ import annotations
import argparse
import concurrent.futures
import copy
import datetime as dt
import fcntl
import hashlib
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from guide_reader import safe_url,decode_page,parse_guide
import desktop_support

VERSION='2.7.0'
ROOT=Path(__file__).resolve().parent
CATALOG=json.loads((ROOT/'catalog.json').read_text(encoding='utf-8'))
CATEGORIES=CATALOG['categories'];BASE=CATALOG['items']
IDS={x['id'] for x in BASE};CAT_IDS={x['id'] for x in CATEGORIES}
MAX_BODY=8*1024*1024

def stamp():return dt.datetime.now(dt.timezone.utc).isoformat(timespec='microseconds')
def data_folder():
    explicit=os.environ.get('OOT_CHECKLIST_DATA_DIR')
    if explicit:return Path(explicit).expanduser().resolve()
    xdg=os.environ.get('XDG_DATA_HOME','')
    return (Path(xdg) if xdg and Path(xdg).is_absolute() else Path.home()/'.local'/'share')/'oot-herzteil-checkliste'
def atomic_bytes(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,temp=tempfile.mkstemp(prefix='.'+path.name,dir=str(path.parent))
    try:
        with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(temp,path)
    finally:
        if os.path.exists(temp):os.unlink(temp)
def atomic_json(path,data):atomic_bytes(path,json.dumps(data,ensure_ascii=False,indent=2).encode('utf-8'))
def empty_state():return dict(app='oot-sammel-checklisten',version=2,checked=[],notes={},updated='')
def validate_state(raw):
    if not isinstance(raw,dict):raise ValueError('Keine passende Sicherungsdatei.')
    legacy=raw.get('app')=='oot-herzteil-checkliste' and raw.get('version')==1
    if not legacy and not(raw.get('app')=='oot-sammel-checklisten' and raw.get('version')==2):raise ValueError('Diese Sicherung geh\u00f6rt nicht zu dieser App.')
    checked=raw.get('checked',[]);notes=raw.get('notes',{})
    if not isinstance(checked,list) or not isinstance(notes,dict):raise ValueError('Ung\u00fcltige H\u00e4kchen oder Notizen.')
    if legacy:
        if any(type(n) is not int or not 1<=n<=36 for n in checked):raise ValueError('Ung\u00fcltige Herzteilnummer.')
        if any(k not in {str(i) for i in range(1,37)} for k in notes):raise ValueError('Ung\u00fcltige Herzteilnotiz.')
        checked=[f'herzen:{n:03d}' for n in checked];notes={f'herzen:{int(k):03d}':v for k,v in notes.items()}
    if any(not isinstance(n,str) or n not in IDS for n in checked) or len(set(checked))!=len(checked):raise ValueError('Ung\u00fcltige oder doppelte Listenpunkte.')
    if any(k not in IDS or not isinstance(v,str) or len(v)>2000 for k,v in notes.items()):raise ValueError('Ung\u00fcltige Notiz (maximal 2000 Zeichen).')
    return dict(app='oot-sammel-checklisten',version=2,checked=sorted(checked),notes={k:v for k,v in notes.items() if v},updated=str(raw.get('updated',''))[:64])
def image_key(url):return hashlib.sha256(url.encode()).hexdigest()
def image_type(raw):
    if raw.startswith(b'\x89PNG\r\n\x1a\n'):return 'image/png'
    if raw.startswith(b'\xff\xd8\xff'):return 'image/jpeg'
    if raw[:4]==b'RIFF' and raw[8:12]==b'WEBP':return 'image/webp'
    return None
class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        return super().redirect_request(req,fp,code,msg,headers,safe_url(newurl))
def download(url,limit=MAX_BODY):
    url=safe_url(url)
    req=urllib.request.Request(url,headers={'User-Agent':'OoT-Sammel-Checklisten/2.5 (local personal guide reader)','Referer':'https://zeldachronicles.de/spiele/oot/','Accept':'text/html,image/png,image/jpeg;q=0.9,*/*;q=0.5'})
    with urllib.request.build_opener(SafeRedirect()).open(req,timeout=12) as response:
        safe_url(response.geturl());raw=response.read(limit+1)
        if len(raw)>limit:raise ValueError('Datei zu gro\u00df.')
        return raw,response.headers.get_content_charset()

class Store:
    def __init__(self,directory,network=True):
        self.directory=directory;directory.mkdir(parents=True,exist_ok=True)
        try:directory.chmod(0o700)
        except OSError:pass
        self.lock=threading.RLock();self.path=directory/'fortschritt-v2.json'
        self.warning='';self.state=empty_state();self.migrated=False;self.network=network
        if self.path.exists():
            try:self.state=validate_state(json.loads(self.path.read_text(encoding='utf-8')))
            except (OSError,ValueError,TypeError) as exc:
                safe=directory/('fortschritt-v2-beschaedigt-'+str(time.time_ns())+'.json');shutil.copy2(self.path,safe)
                self.warning='Die Fortschrittsdatei war nicht lesbar. Eine Kopie wurde gesichert. Bitte eine Sicherung laden.'
                old=directory/'fortschritt-v2.vorher.json'
                if old.exists():
                    try:
                        self.state=validate_state(json.loads(old.read_text(encoding='utf-8')))
                        atomic_json(self.path,self.state);self.warning+=' Der letzte vorherige Stand wurde wiederhergestellt.'
                    except (OSError,ValueError,TypeError):pass
        elif (directory/'fortschritt.json').exists():
            try:
                raw=json.loads((directory/'fortschritt.json').read_text(encoding='utf-8'))
                self.state=validate_state(raw)
                atomic_json(directory/'herzteile-v1-vor-update.json',raw)
                atomic_json(self.path,self.state);self.migrated=True
                self.warning='Deine bisherigen Herzteil-H\u00e4kchen und Notizen wurden \u00fcbernommen. Die alte Datei bleibt unver\u00e4ndert.'
            except (OSError,ValueError,TypeError):
                self.warning='Die alte Herzteil-Datei konnte nicht sicher \u00fcbernommen werden. Sie wurde nicht ver\u00e4ndert. Bitte deine bisherige Sicherung laden.'
        self.items=copy.deepcopy(BASE);self.guides={c['id']:dict(loaded=False,error='',updated='') for c in CATEGORIES}
        self.revision=0;self.refreshing=False;self.stage='';self.done=0;self.total=0;self.job_error=''
        self.cached=set();self.urls={}
        for c in CATEGORIES:
            path=directory/'vorlagen-v2'/(c['id']+'.json')
            if path.exists():
                try:self.set_guide(c['id'],json.loads(path.read_text(encoding='utf-8')),persist=False)
                except (OSError,ValueError,TypeError,KeyError):self.guides[c['id']]['error']='Gespeicherte Vorlage ist nicht lesbar.'
        # Reuse the first app's locally cached text and all 36 images.
        if not self.guides['herzen']['loaded'] and (directory/'vorlage.json').exists():
            try:
                old=json.loads((directory/'vorlage.json').read_text(encoding='utf-8'))['items']
                if len(old)==36 and [x['id'] for x in old]==list(range(1,37)):
                    hearts=[copy.deepcopy(i) for i in BASE if i['category']=='herzen']
                    for new,previous in zip(hearts,old):
                        desc=previous.get('description','')
                        if not isinstance(desc,str):raise ValueError('Invalid old description')
                        new['description']=desc[:6000]
                    self.set_guide('herzen',dict(items=hearts,updated=stamp()))
            except (OSError,ValueError,TypeError,KeyError):pass
        self.reindex()
        for i in range(1,37):
            src=directory/'bilder'/f'{i:02d}.img'
            u=next(x for x in self.items if x['id']==f'herzen:{i:03d}')['images'][0]
            dest=self.image_path(image_key(u))
            if src.exists() and not dest.exists():
                try:
                    raw=src.read_bytes()
                    if image_type(raw):atomic_bytes(dest,raw);self.cached.add(image_key(u))
                except OSError:pass
    def snapshot(self):
        with self.lock:return copy.deepcopy(self.state)
    def mutate(self,operation,data):
        with self.lock:
            result=copy.deepcopy(self.state)
            if operation in ('check','note'):
                i=data.get('id')
                if not isinstance(i,str) or i not in IDS:raise ValueError('Unbekannter Listenpunkt.')
                if operation=='check':
                    if type(data.get('checked')) is not bool:raise ValueError('Ung\u00fcltiger Haken.')
                    checks=set(result['checked']);checks.add(i) if data['checked'] else checks.discard(i);result['checked']=sorted(checks)
                else:
                    value=data.get('note')
                    if not isinstance(value,str) or len(value)>2000:raise ValueError('Notiz zu lang.')
                    if value:result['notes'][i]=value
                    else:result['notes'].pop(i,None)
            elif operation=='reset':
                cat=data.get('category')
                if cat not in CAT_IDS|{'all'}:raise ValueError('Unbekannter Bereich.')
                result['checked']=[i for i in result['checked'] if cat!='all' and i.split(':')[0]!=cat]
            elif operation=='import':
                raw=data.get('state');incoming=validate_state(raw)
                if raw.get('version')==1:
                    result['checked']=sorted([i for i in result['checked'] if not i.startswith('herzen:')]+incoming['checked'])
                    result['notes']={k:v for k,v in result['notes'].items() if not k.startswith('herzen:')};result['notes'].update(incoming['notes'])
                else:result=incoming
            else:raise ValueError('Unbekannte Aktion.')
            result['updated']=stamp()
            atomic_json(self.directory/'fortschritt-v2.vorher.json',self.state)
            if operation in ('reset','import'):atomic_json(self.directory/('sicherung-v2-'+str(time.time_ns())+'.json'),self.state)
            atomic_json(self.path,result);self.state=result
            return copy.deepcopy(result)
    def image_path(self,digest):return self.directory/'bilder-v2'/(digest+'.img')
    def reindex(self):
        with self.lock:
            self.urls={image_key(u):u for i in self.items for u in i['images']}
            self.cached={k for k in self.urls if self.image_path(k).exists()}
    def set_guide(self,cat,data,persist=True):
        items=data.get('items');expected=[i['id'] for i in BASE if i['category']==cat]
        if not isinstance(items,list) or [i.get('id') for i in items]!=expected:raise ValueError('Falsche Listenpunkte in der Vorlage.')
        for i in items:
            if i.get('category')!=cat or not isinstance(i.get('description'),str) or len(i['description'])>6000:raise ValueError('Ung\u00fcltiger Vorlagentext.')
            if not isinstance(i.get('images'),list) or not 1<=len(i['images'])<=40:raise ValueError('Ung\u00fcltige Bilderliste.')
            for u in i['images']:safe_url(u)
        saved=dict(items=items,updated=str(data.get('updated',stamp()))[:64])
        if persist:atomic_json(self.directory/'vorlagen-v2'/(cat+'.json'),saved)
        with self.lock:
            byid={i['id']:i for i in items}
            self.items=[copy.deepcopy(byid.get(i['id'],i)) for i in self.items]
            self.guides[cat]=dict(loaded=True,error='',updated=saved['updated']);self.revision+=1
    def guide_snapshot(self):
        with self.lock:
            data=copy.deepcopy(self.items)
            for item in data:
                item['pictures']=[dict(url=u,key=image_key(u),cached=image_key(u) in self.cached) for u in item['images']]
            return dict(categories=CATEGORIES,items=data,guides=copy.deepcopy(self.guides),revision=self.revision,network=self.network)
    def status(self):
        with self.lock:
            return dict(refreshing=self.refreshing,stage=self.stage,done=self.done,total=self.total,error=self.job_error,
                        cached_images=len(self.cached),total_images=len(self.urls),guides=copy.deepcopy(self.guides),revision=self.revision,
                        cached_keys=sorted(self.cached),network=self.network)
    def cache_image(self,u):
        k=image_key(u)
        if self.image_path(k).exists():return True
        try:
            raw,_=download(u)
            if not image_type(raw):return False
            atomic_bytes(self.image_path(k),raw)
            with self.lock:self.cached.add(k)
            return True
        except (OSError,ValueError,urllib.error.URLError):return False
    def refresh(self,cat='all',force=True):
        if cat not in CAT_IDS|{'all'}:raise ValueError('Unbekannter Bereich.')
        with self.lock:
            if self.refreshing:return False
            self.network=True;self.refreshing=True;self.done=0;self.total=0;self.job_error='';self.stage='Beschreibungen werden geladen ...'
        def work():
            try:
                selected=[c for c in CATEGORIES if cat=='all' or c['id']==cat]
                for c in selected:
                    if not force and self.guides[c['id']]['loaded']:continue
                    with self.lock:self.stage=c['title']+': Beschreibung laden ...'
                    try:
                        raw,charset=download(c['source']);base=[i for i in BASE if i['category']==c['id']]
                        parsed=parse_guide(c,decode_page(raw,charset),base)
                        self.set_guide(c['id'],dict(items=parsed,updated=stamp()))
                    except Exception as exc:
                        with self.lock:self.guides[c['id']]['error']='Vorlage nicht geladen: '+str(exc)[:160]
                self.reindex()
                with self.lock:
                    items=[copy.deepcopy(i) for i in self.items if cat=='all' or i['category']==cat]
                # First download one picture per entry, then gallery extras.
                urls=list(dict.fromkeys([i['images'][0] for i in items]+[u for i in items for u in i['images'][1:]]))
                missing=[u for u in urls if not self.image_path(image_key(u)).exists()]
                with self.lock:self.total=len(missing);self.done=0;self.stage='Bilder werden lokal gespeichert ...'
                failures=0
                # Small batches cap concurrent connections and allow a quick,
                # bounded abort when the entire network is unavailable.
                with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
                    for start in range(0,len(missing),3):
                        results=list(pool.map(self.cache_image,missing[start:start+3]))
                        for ok in results:
                            failures=0 if ok else failures+1
                            with self.lock:self.done+=1
                        if failures>=9:
                            with self.lock:self.job_error='Bilddownload unterbrochen. Internet pr\u00fcfen und erneut laden. Vorhandene Bilder und H\u00e4kchen bleiben erhalten.'
                            break
                with self.lock:
                    remaining=sum(not self.image_path(image_key(u)).exists() for u in urls)
                    if remaining and not self.job_error:self.job_error=str(remaining)+' Bilder noch nicht lokal vorhanden. Du kannst sie erneut laden.'
                    self.stage='Ladevorgang beendet.';self.revision+=1
            except Exception as exc:
                with self.lock:self.job_error='Laden fehlgeschlagen: '+str(exc)[:200]
            finally:
                with self.lock:self.refreshing=False
        threading.Thread(target=work,daemon=True,name='guide-download').start();return True
    def import_html(self,cat,html):
        if cat not in CAT_IDS or not isinstance(html,str) or len(html)>MAX_BODY:raise ValueError('Ung\u00fcltige HTML-Datei oder Kategorie.')
        c=next(c for c in CATEGORIES if c['id']==cat)
        parsed=parse_guide(c,html,[i for i in BASE if i['category']==cat])
        self.set_guide(cat,dict(items=parsed,updated=stamp()));self.reindex()
        return True

class Handler(BaseHTTPRequestHandler):
    server_version='OoTChecklist/2.5';sys_version=''
    def log_message(self,fmt,*args):pass
    def respond(self,payload,code=200,kind='application/json; charset=utf-8'):
        self.send_response(code);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(payload)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https://zeldachronicles.de https://www.zeldachronicles.de https://zeldaeurope.de https://www.zeldaeurope.de; connect-src 'self'; base-uri 'self'; form-action 'none'; frame-ancestors 'none'")
        self.end_headers()
        try:self.wfile.write(payload)
        except (BrokenPipeError,ConnectionResetError):pass
    def json(self,data,code=200):self.respond(json.dumps(data,ensure_ascii=False).encode(),code)
    def route(self):
        if self.headers.get('Host')!=self.server.expected_host:self.json({'error':'Unzul\u00e4ssiger Host.'},403);return None
        path=urllib.parse.urlsplit(self.path).path;prefix='/'+self.server.token+'/'
        if not path.startswith(prefix):self.json({'error':'Bitte die App mit STARTEN.sh \u00f6ffnen.'},403);return None
        return path[len(prefix):]
    def do_GET(self):
        route=self.route()
        if route is None:return
        s=self.server.store
        if route=='api/ping':self.json(dict(app='oot-herzteil-checkliste',version=VERSION))
        elif route=='api/state':self.json(dict(state=s.snapshot(),warning=s.warning,path=str(s.path),version=VERSION))
        elif route=='api/guide':self.json(s.guide_snapshot())
        elif route=='api/status':self.json(s.status())
        elif route=='api/system':self.json(desktop_support.system_summary())
        elif route=='api/diagnostic':
            report,ok=desktop_support.diagnostic_text(sys.modules[__name__],s.directory)
            self.json(dict(report=report,ok=ok))
        elif route in ('','index.html','style.css','ui.js','nobara-ui.js','icon.svg','placeholder.svg'):
            name=route or 'index.html';kinds={'index.html':'text/html; charset=utf-8','style.css':'text/css; charset=utf-8','ui.js':'text/javascript; charset=utf-8','nobara-ui.js':'text/javascript; charset=utf-8','icon.svg':'image/svg+xml','placeholder.svg':'image/svg+xml'}
            try:self.respond((ROOT/name).read_bytes(),kind=kinds[name])
            except OSError:self.json({'error':'App-Datei fehlt. Bitte das gesamte Archiv entpacken.'},500)
        elif re.fullmatch(r'image/[0-9a-f]{64}',route):
            digest=route.split('/')[1]
            if digest not in s.urls:self.json({'error':'Unbekanntes Bild.'},404);return
            try:
                raw=s.image_path(digest).read_bytes();kind=image_type(raw)
                if not kind:raise ValueError()
                self.respond(raw,kind=kind)
            except (OSError,ValueError):self.json({'error':'Dieses Bild ist noch nicht lokal gespeichert.'},404)
        else:self.json({'error':'Nicht gefunden.'},404)
    def do_POST(self):
        route=self.route()
        if route is None:return
        origin=self.headers.get('Origin')
        if origin is not None and origin!='http://'+self.server.expected_host:self.json({'error':'Fremde Webseiten d\u00fcrfen keine Daten \u00e4ndern.'},403);return
        if self.headers.get('Content-Type','').split(';')[0].strip()!='application/json':self.json({'error':'JSON erwartet.'},415);return
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=MAX_BODY:raise ValueError('Ung\u00fcltige Dateigr\u00f6\u00dfe.')
            data=json.loads(self.rfile.read(size).decode('utf-8'))
            if not isinstance(data,dict):raise ValueError('Ung\u00fcltige Anfrage.')
            if route in ('api/check','api/note','api/reset','api/import'):self.json({'state':self.server.store.mutate(route.split('/')[1],data)})
            elif route=='api/refresh':self.json({'started':self.server.store.refresh(data.get('category','all'))})
            elif route=='api/import-guide':self.json({'ok':self.server.store.import_html(data.get('category'),data.get('html'))})
            elif route=='api/shutdown':
                self.json({'ok':True});threading.Thread(target=self.server.shutdown,daemon=True).start()
            else:self.json({'error':'Nicht gefunden.'},404)
        except (ValueError,TypeError,KeyError,UnicodeDecodeError) as exc:self.json({'error':str(exc)},400)
        except OSError:self.json({'error':'Speichern fehlgeschlagen. Schreibrechte und freien Speicherplatz pr\u00fcfen.'},500)

def running(directory):
    try:
        meta=json.loads((directory/'laufend.json').read_text(encoding='utf-8'));port,token=meta['port'],meta['token']
        if type(port)is not int or not 1024<=port<=65535 or not re.fullmatch(r'[a-f0-9]{48}',token):return None
        url=f'http://127.0.0.1:{port}/{token}/'
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(url+'api/ping',timeout=0.7) as r:
            data=json.load(r)
            if data.get('app')=='oot-herzteil-checkliste':return (url,str(data.get('version','1.0')))
    except (OSError,ValueError,KeyError,TypeError,urllib.error.URLError):pass
    return None

def serve(directory,no_download=False):
    directory.mkdir(parents=True,exist_ok=True);lock=os.fdopen(os.open(str(directory/'server.lock'),os.O_CREAT|os.O_RDWR,0o600),'a+')
    try:fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:lock.close();return 0
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
    server.store=Store(directory,network=not no_download);server.token=secrets.token_hex(24);server.expected_host='127.0.0.1:'+str(server.server_port)
    meta=directory/'laufend.json';atomic_json(meta,dict(port=server.server_port,token=server.token,pid=os.getpid(),version=VERSION))
    print('App ready on loopback port',server.server_port,flush=True)
    if not no_download and (len(server.store.cached)<len(server.store.urls) or not all(x['loaded'] for x in server.store.guides.values())):server.store.refresh(force=False)
    try:server.serve_forever(poll_interval=.2)
    except KeyboardInterrupt:pass
    finally:server.server_close();meta.unlink(missing_ok=True);lock.close()
    return 0

def desktop_value(text):return text.replace('\\','\\\\').replace('\n','\\n')
def desktop_arg(text):return '"'+text.replace('%','%%').replace('\\','\\\\').replace('"','\\"').replace('`','\\`').replace('$','\\$')+'"'
def install():
    return desktop_support.install_app(sys.modules[__name__])

def open_browser(url):
    return desktop_support.open_browser(url)

def write_browser_link(url):
    """A manual fallback if desktop URL handling is unavailable."""
    from html import escape
    page=('''<!doctype html><html lang="de"><meta charset="utf-8"><title>OoT App oeffnen</title>
<style>body{font:18px system-ui;background:#102c24;color:#f2eed9;max-width:800px;margin:10vh auto;padding:30px;line-height:1.7}a{color:#dfc777;overflow-wrap:anywhere}</style>
<h1>Deine OoT-Checkliste</h1><p>Die Linux-App wurde gestartet. Klicke auf den Link:</p><p><a href="'''+escape(url,quote=True)+'">Checkliste im Browser oeffnen</a></p><p>Falls der Link nicht mehr erreichbar ist, zuerst STARTEN.sh erneut ausfuehren. Fuer den Start ohne Python gibt es DIREKTSTART.html (separater Browser-Spielstand).</p></html>''')
    try:
        path=ROOT/'APP_IM_BROWSER.html';atomic_bytes(path,page.encode('utf-8'));path.chmod(0o600)
        return path
    except OSError:return None

def stop_running(directory):
    live=running(directory)
    if not live:return True
    request=urllib.request.Request(live[0]+'api/shutdown',data=b'{}',headers={'Content-Type':'application/json'},method='POST')
    try:
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=5) as response:
            if response.status!=200:return False
    except (OSError,ValueError,urllib.error.URLError):return False
    for _ in range(80):
        if not running(directory):
            try:
                with open(directory/'server.lock','a+') as handle:
                    fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
                return True
            except (BlockingIOError,OSError):pass
        time.sleep(.1)
    return False

def diagnose(directory):
    report,ok=desktop_support.diagnostic_text(sys.modules[__name__],directory)
    print(report)
    path=directory/'OoT-Nobara-Diagnose.txt'
    try:
        atomic_bytes(path,report.encode('utf-8'))
        print('Diagnose gespeichert:',path)
    except OSError:
        print('Diagnose konnte nicht gespeichert werden. Bitte Terminaltext kopieren.')
    return 0 if ok else 1

def start(directory,no_download=False,no_browser=False,restart=False):
    directory.mkdir(parents=True,exist_ok=True)
    if restart and not stop_running(directory):
        print('Die laufende App konnte nicht sicher beendet werden. Bitte in der alten App "App beenden" waehlen. Es wurden keine Daten geloescht.',file=sys.stderr)
        return 2
    live=running(directory)
    if live and live[1]!=VERSION:
        print('Eine andere App-Version laeuft noch ('+live[1]+'). Bitte dort zuerst speichern und unter "Sichern & verwalten > App beenden" schliessen. Danach STARTEN.sh erneut ausfuehren.\nLaufende App: '+live[0],flush=True)
        write_browser_link(live[0])
        if not no_browser:open_browser(live[0])
        return 2
    if not live:
        cmd=[sys.executable,'-I',str(ROOT/'launcher.py'),'--serve']+(['--no-download'] if no_download else [])
        env=dict(os.environ,OOT_CHECKLIST_DATA_DIR=str(directory))
        with open(directory/'programm-v2.log','ab') as log:
            child=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=log,stderr=log,cwd=str(ROOT),env=env,start_new_session=True,close_fds=True)
        for _ in range(100):
            time.sleep(.1);live=running(directory)
            if live:break
            if child.poll() is not None:break
    if not live:
        print('Start fehlgeschlagen. Details:',directory/'programm-v2.log',file=sys.stderr)
        try:
            with open(directory/'programm-v2.log','rb') as log:
                log.seek(0,2);log.seek(max(0,log.tell()-5000))
                print(log.read().decode('utf-8','replace'),file=sys.stderr)
        except OSError:pass
        print('Ohne Python/Server: DIREKTSTART.html im Browser oeffnen (separater Spielstand).',file=sys.stderr)
        return 1
    print('OoT Sammel-Checklisten '+VERSION+'\n\nBrowser-Adresse:\n'+live[0]+'\n',flush=True)
    link=write_browser_link(live[0])
    if no_browser:return 0
    print('Browser wird geoeffnet. Falls kein Fenster erscheint, die Browser-Adresse oben kopieren.',flush=True)
    if open_browser(live[0]):return 0
    print('Die Checkliste laeuft, aber der Browser konnte nicht automatisch geoeffnet werden.\nDie Adresse oben in Firefox oder Chromium einfuegen.',flush=True)
    if link:print('Alternativ diese Datei im Browser oeffnen:',link,flush=True)
    return 3

def main():
    p=argparse.ArgumentParser(description='OoT Sammel-Checklisten 2.5 - Nobara Edition')
    p.add_argument('--serve',action='store_true')
    p.add_argument('--install',action='store_true')
    p.add_argument('--install-start',action='store_true',help='Ins eigene Benutzerkonto installieren und starten.')
    p.add_argument('--desktop',action='store_true',help='Fehler auch als Desktop-Dialog anzeigen.')
    p.add_argument('--no-download',action='store_true',help='Beim neuen Serverstart keine Online-Bilder oder Downloads.')
    p.add_argument('--no-browser',action='store_true')
    p.add_argument('--diagnose',action='store_true',help='Diagnose ohne Notizen, Spielstand oder Sitzungstoken.')
    p.add_argument('--restart',action='store_true',help='Nur die gepruefte lokale App beenden. Vorher offene Notizen speichern!')
    p.add_argument('--stop',action='store_true',help='Nur den lokalen Checklisten-Server beenden, keine Daten loeschen.')
    args=p.parse_args()
    directory=data_folder()
    if args.diagnose:return diagnose(directory)
    if args.stop:
        ok=stop_running(directory)
        print('App beendet. Gespeicherter Fortschritt bleibt erhalten.' if ok else 'App konnte nicht sicher beendet werden.')
        return 0 if ok else 2
    if args.install or args.install_start:
        if args.restart and not stop_running(directory):
            print('Die laufende App konnte nicht sicher beendet werden. Installation abgebrochen.')
            return 2
        code=install()
        if code or not args.install_start:return code
        # Always run the installed copy, never the self-extractor's temp files.
        command=[sys.executable,'-I',str(desktop_support.install_target()/'launcher.py')]
        if args.no_download:command.append('--no-download')
        if args.no_browser:command.append('--no-browser')
        # The outer launcher owns error dialogs; do not show duplicates.
        return subprocess.call(command,env=dict(os.environ,OOT_GUI='0'))
    return serve(directory,args.no_download) if args.serve else start(directory,args.no_download,args.no_browser,args.restart)
if __name__=='__main__':
    try:raise SystemExit(main())
    except (OSError,ValueError) as exc:print('Fehler:',str(exc),file=sys.stderr);raise SystemExit(1)
