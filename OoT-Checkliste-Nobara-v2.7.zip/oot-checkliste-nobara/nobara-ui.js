'use strict';
/* Small desktop-support panel. Does not change checklist or backup formats. */
(async function () {
  const summary=document.getElementById('nobara-system');
  const button=document.getElementById('nobara-diagnostic');
  if (!summary || !button) return;
  try {
    const response=await fetch('api/system',{cache:'no-store'});
    if (!response.ok) throw new Error('Systemdaten nicht erreichbar');
    const data=await response.json();
    summary.textContent=[data.edition,data.system,data.desktop,data.session].join(' \u00b7 ');
  } catch (_) {summary.textContent='Nobara Edition 2.3 \u00b7 lokale Linux-App';}
  button.addEventListener('click',async()=>{
    button.disabled=true;
    try {
      const response=await fetch('api/diagnostic',{cache:'no-store'});
      if (!response.ok) throw new Error('Diagnose konnte nicht erstellt werden.');
      const data=await response.json();
      const url=URL.createObjectURL(new Blob([data.report],{type:'text/plain;charset=utf-8'}));
      const link=document.createElement('a');link.href=url;link.download='OoT-Nobara-Diagnose.txt';
      document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);
    } catch (_) {summary.textContent='Keine Verbindung. Bitte DIAGNOSE.sh im Programmordner ausfuehren.';}
    finally {button.disabled=false;}
  });
})();
