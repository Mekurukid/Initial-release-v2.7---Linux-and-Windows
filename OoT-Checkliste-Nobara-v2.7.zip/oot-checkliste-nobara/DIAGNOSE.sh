#!/bin/sh
set -u
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd) || exit 1
/bin/sh "$HERE/STARTEN.sh" --diagnose "$@"
rc=$?
if [ -t 0 ] && [ "${OOT_NO_PAUSE:-0}" != 1 ]; then
    printf '\n%s\n' 'Die Diagnose kannst du kopieren oder fotografieren. Enter zum Schliessen.'
    IFS= read -r answer || :
fi
exit "$rc"
