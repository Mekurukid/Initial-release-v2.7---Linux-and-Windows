#!/bin/sh
# Nobara: /bin/sh + isolated system Python; no pip, Wine, FUSE or chmod needed.
set -u
umask 077
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd) || exit 1
# Only scripts launched from the desktop need GUI error reporting.
if [ -z "${OOT_GUI+x}" ]; then
    if [ ! -t 1 ] && { [ -n "${WAYLAND_DISPLAY:-}" ] || [ -n "${DISPLAY:-}" ]; }; then
        OOT_GUI=1
    else
        OOT_GUI=0
    fi
    export OOT_GUI
fi
fail() {
    printf '\n%s\n' "$1" >&2
    if [ "${OOT_GUI:-0}" = 1 ]; then
        if command -v kdialog >/dev/null 2>&1; then
            kdialog --title 'OoT - Nobara Start' --error "$1" 2>/dev/null || :
        elif command -v zenity >/dev/null 2>&1; then
            zenity --error --title='OoT - Nobara Start' --text="$1" 2>/dev/null || :
        fi
    fi
    exit 1
}
finish() {
    rc=$?
    if [ "$rc" -ne 0 ] && [ -t 0 ] && [ "${OOT_NO_PAUSE:-0}" != 1 ]; then
        printf '\n%s\n' 'Die Fehlermeldung bleibt sichtbar. Enter zum Schliessen.'
        IFS= read -r answer || :
    fi
}
trap finish EXIT
printf '%s\n' 'OoT Sammel-Checklisten - Nobara Edition 2.7' ''
if [ "$(id -u)" = 0 ] && [ "${OOT_ALLOW_ROOT:-0}" != 1 ]; then
    fail 'Bitte OHNE sudo und NICHT als root starten. Installation und Spielstand gehoeren in dein normales Benutzerkonto.'
fi
if [ -x /usr/bin/python3 ]; then
    PYTHON=/usr/bin/python3
elif command -v python3 >/dev/null 2>&1; then
    PYTHON=$(command -v python3)
else
    fail 'Python 3 fehlt. Auf Nobara zuerst im Terminal ausfuehren: sudo dnf install python3 xdg-utils. Danach dieses Programm OHNE sudo starten.'
fi
if ! "$PYTHON" -I -c 'import sys; sys.exit(sys.version_info < (3, 8))'; then
    fail 'Python 3.8 oder neuer wird benoetigt. Auf Nobara: sudo dnf install python3'
fi
for name in launcher.py desktop_support.py app.py guide_reader.py catalog.json index.html ui.js nobara-ui.js style.css icon.svg placeholder.svg; do
    if [ ! -f "$HERE/$name" ]; then
        fail "Datei fehlt: $name. Bitte das GESAMTE Archiv entpacken, nicht nur STARTEN.sh. Einfacher: den Einzeldatei-Installer verwenden."
    fi
done
"$PYTHON" -I -u "$HERE/launcher.py" "$@"
exit $?
