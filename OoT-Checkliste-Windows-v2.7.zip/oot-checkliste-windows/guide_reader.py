"""Read the ten selected public guides as text only; never execute remote HTML."""
from __future__ import annotations
import copy
import re
import unicodedata
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit, urlunsplit

HOSTS = {'zeldachronicles.de','www.zeldachronicles.de','zeldaeurope.de','www.zeldaeurope.de'}
IMAGE_NAME = re.compile(r'oot_(?:herzteile|skulltula|tauschgeschaeft|maskenhandel|nacht|feen|wundererbse|flaschen?|lieder|ausruestung)_\d+[a-z]?\.(?:png|jpe?g|webp)$',re.I)

def normal(s): return re.sub(r'\s+', ' ', s.replace('\xa0', ' ')).strip()
def key(s):
    return re.sub(r'[^a-z0-9]', '', unicodedata.normalize('NFKD',s.casefold()).encode('ascii','ignore').decode())
def safe_url(url):
    p=urlsplit(url)
    if p.scheme not in ('http','https') or p.hostname not in HOSTS or p.port not in (None,80,443) or p.username or p.password:
        raise ValueError('Nicht erlaubte Quellenadresse.')
    return urlunsplit(('https',p.hostname,p.path,p.query,''))
def decode_page(raw, charset=None):
    m=re.search(br'charset\s*=\s*["\x27]?([\w-]+)',raw[:7000],re.I)
    for enc in dict.fromkeys(['utf-8-sig',m.group(1).decode('ascii') if m else None,charset,'windows-1252','latin-1']):
        if enc:
            try:return raw.decode(enc)
            except (UnicodeDecodeError,LookupError):pass
    return raw.decode('utf-8','replace')

class Page(HTMLParser):
    blocks={'div','p','br','hr','tr','td','th','table','h1','h2','h3','h4','li','ul','ol','center'}
    skip_tags={'script','style','head','noscript','iframe','svg'}
    def __init__(self,source):
        super().__init__(convert_charrefs=True)
        self.source=source;self.parts=[];self.images=[];self.skip=[]
    def picture(self,src,thumb=False):
        try:u=safe_url(urljoin(self.source,src))
        except (ValueError,TypeError):return
        if not IMAGE_NAME.search(urlsplit(u).path):return
        # Only SMALL thumbnails are promoted; e.g. the blue tunic '25a' is
        # a genuine full-size image and must never be changed into '25'.
        if thumb:u=re.sub(r'(\d)a(\.jpe?g)$',r'\1\2',u,flags=re.I)
        self.images.append(u);self.parts.append('\n[[IMG:'+str(len(self.images)-1)+']]\n')
    def handle_starttag(self,tag,attrs):
        if tag in self.skip_tags:
            self.skip.append(tag);return
        if self.skip:return
        a=dict(attrs)
        if tag in self.blocks:self.parts.append('\n')
        if tag=='li':self.parts.append('[[LI]]')
        if tag=='img':
            try:small=0<int(re.sub(r'\D','',a.get('width','')) or 0)<=100
            except (ValueError,TypeError):small=False
            self.picture(a.get('src') or a.get('data-src') or '',small)
        if tag=='a' and a.get('href'):self.picture(a['href'])
        # Legacy galleries put full-size filenames in mouseover attributes.
        # They are parsed as strings only, not evaluated as JavaScript.
        for name,value in attrs:
            if value and name in ('onmouseover','onmouseenter','onclick'):
                for m in re.finditer(r'''["']([^"']+\.(?:jpg|jpeg|png|webp))["']''',value,re.I):self.picture(m.group(1))
    def handle_endtag(self,tag):
        if self.skip:
            if tag==self.skip[-1]:self.skip.pop()
            return
        if tag=='li':self.parts.append('[[/LI]]')
        if tag in self.blocks:self.parts.append('\n')
    def handle_data(self,data):
        if not self.skip:self.parts.append(re.sub(r'\s+',' ',data))
    def text(self):return ''.join(self.parts)
    def image_list(self,block):
        return list(dict.fromkeys(self.images[int(n)] for n in re.findall(r'\[\[IMG:(\d+)\]\]',block)))

def plain(block):
    text=re.sub(r'\[\[IMG:\d+\]\]','',block)
    text=text.replace('[[LI]]','\n').replace('[[/LI]]','\n')
    text=re.split(r'Projekt Zelda|The Legend of Zelda und alle',text)[0]
    text=re.sub(r'Fahre mit der Maus.*?(?:sehen\.|verstehen\.)','',text,flags=re.S|re.I)
    text=re.sub(r'Klick die nachfolgenden.*?(?:sehen\.|verstehen\.)','',text,flags=re.S|re.I)
    return '\n'.join(normal(s) for s in text.splitlines() if normal(s))[:6000]

def parse_guide(category,html,base):
    """Return the same IDs, or fail without changing any existing guide data."""
    page=Page(category['source']);page.feed(html);page.close();text=page.text()
    cat=category['id'];items=copy.deepcopy(base);bounds=[]
    if cat=='skulltula':
        pattern=r'\u00bb\s*([^\u00ab\n]{1,140}?)\s*\[(\d+)\s+Goldene\s+Skulltulas?\]\s*\u00ab'
        headings=list(re.finditer(pattern,text,re.I))
        if not headings:raise ValueError('Die Skulltula-Gebiete wurden nicht erkannt.')
        pos=0
        for i,m in enumerate(headings):
            count=int(m.group(2));region=normal(m.group(1));end=headings[i+1].start() if i+1<len(headings) else len(text)
            block=text[m.end():end]
            lis=re.findall(r'\[\[LI\]\](.*?)(?:\[\[/LI\]\]|(?=\[\[LI\]\]))',block,re.S)
            if len(lis)!=count or pos+count>len(items):raise ValueError('Die Fundorte eines Skulltula-Gebiets sind unvollst\u00e4ndig.')
            if any(key(items[pos+j]['region'])!=key(region) for j in range(count)):
                raise ValueError('Die Gebietsreihenfolge hat sich ge\u00e4ndert. Keine H\u00e4kchen wurden verschoben.')
            images=page.image_list(block)
            for j,li in enumerate(lis):
                item=items[pos+j];desc=plain(li)
                if len(desc)<8:raise ValueError('Eine Fundortbeschreibung fehlt.')
                item['description']=desc
                # Prefer the established per-entry image identity over the
                # default gallery preview, which need not be the first item.
                expected=r'_(?:0*)'+str(item['number'])+r'\.jpe?g$'
                found=[u for u in images if re.search(expected,u,re.I)]
                if found:item['images']=[found[0]]
            pos+=count
        if pos!=100:raise ValueError('Es wurden nicht alle 100 Skulltulas erkannt.')
        return items
    if cat in ('feen','upgrades'):
        candidates=list(re.finditer(r'\u00bb\s*([^\u00ab]{1,220}?)\s*\u00ab',text))
        for m in candidates:
            h=normal(re.sub(r'\[\[IMG:\d+\]\]','',m.group(1)))
            if cat=='feen':ok=bool(re.match(r'(?:Gro\u00dfe Fee|\d+\.\s*Feenquelle)',h,re.I))
            else:ok=bool(re.match(r'(?:Das |Der |Die |Upgrade:)',h))
            if ok:bounds.append((m.start(),m.end(),h))
    elif cat=='songs':
        for item in items:
            wanted=r'\s+'.join(re.escape(w) for w in item['source_title'].split())
            m=re.search(r'(?m)^[ \t]*'+wanted+r'[ \t]*(?=\n|$)',text)
            if not m:raise ValueError('Ein Lied wurde in der Vorlage nicht erkannt.')
            bounds.append((m.start(),m.end(),item['title']))
    else:
        # Only section headings count. The seven chicken substeps in the
        # bottle guide must not become seven additional bottles.
        candidates=list(re.finditer(r'(?m)^[ \t]*(\d{1,2})\.[ \t]*([^\n]+)',text))
        expected=1
        for m in candidates:
            if int(m.group(1))!=expected:continue
            head=normal(m.group(2));wanted=items[expected-1]['source_title']
            if cat=='flaschen' and not head.startswith('Flasche:'):continue
            if cat=='herzen' and not re.search(r'Erreichbar\s+als',text[m.end():m.end()+600],re.I):continue
            # Avoid matching an incidental numbered sentence before the list.
            if cat not in ('flaschen','nacht') and key(wanted) not in key(head):continue
            if cat=='nacht' and 'Nachtschw' not in head:continue
            bounds.append((m.start(),m.end(),head));expected+=1
            if expected>len(items):break
    if len(bounds)!=len(items) or [x[0] for x in bounds]!=sorted(x[0] for x in bounds):
        raise ValueError('Die erwarteten '+str(len(items))+' Abschnitte wurden nicht sicher erkannt. Vorhandene Daten bleiben erhalten.')
    for i,(start,end,heading) in enumerate(bounds):
        block=text[end:bounds[i+1][0] if i+1<len(bounds) else len(text)]
        item=items[i]
        # Validate unnumbered order too, before attaching text to stable IDs.
        if cat=='upgrades':
            wanted=key(item['title']);seen=key(heading)
            if not (wanted in seen or ('trag' in seen and key(item['title'].split(' (')[0]) in seen)):
                raise ValueError('Eine Ausr\u00fcstungs\u00fcberschrift hat sich ge\u00e4ndert.')
        if cat=='feen':
            wanted=key(item['title'])
            if wanted not in key(heading):raise ValueError('Eine Feenquelle hat sich ge\u00e4ndert.')
        if cat=='herzen':
            m=re.search(r'Erreichbar\s+als\s*:\s*(Kind(?:\s*\|\s*Erwachsener)?|Erwachsener)',block,re.I)
            if m:block=block[m.end():]
        desc=plain(block)
        if len(desc)<8:raise ValueError('Eine Beschreibung ist unvollst\u00e4ndig.')
        item['description']=desc
        images=page.image_list(block)
        # Supplement the verified main images instead of dropping a working
        # picture because legacy mouseover HTML was incomplete.
        if images:item['images']=list(dict.fromkeys(item['images']+images))[:40]
    return items
