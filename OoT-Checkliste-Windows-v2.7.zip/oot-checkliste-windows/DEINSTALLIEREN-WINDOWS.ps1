param([switch]$AuchSpielstand)
$ErrorActionPreference='Stop'
$LocalAppData=[Environment]::GetFolderPath('LocalApplicationData')
$Target=Join-Path $LocalAppData 'Programs\OoT-Sammel-Checklisten'
$Data=Join-Path $LocalAppData 'OoT-Sammel-Checklisten'
$Shortcut=Join-Path ([Environment]::GetFolderPath('Programs')) 'OoT Sammel-Checklisten.lnk'
if (Test-Path (Join-Path $Target 'launcher.py')) {
  if (Get-Command py.exe -ErrorAction SilentlyContinue) { & py.exe -3 -I (Join-Path $Target 'launcher.py') --stop | Out-Null }
  elseif (Get-Command python.exe -ErrorAction SilentlyContinue) { & python.exe -I (Join-Path $Target 'launcher.py') --stop | Out-Null }
}
if (Test-Path $Shortcut) { Remove-Item $Shortcut -Force }
if (Test-Path $Target) { Remove-Item $Target -Recurse -Force }
if ($AuchSpielstand -and (Test-Path $Data)) { Remove-Item $Data -Recurse -Force }
Write-Host 'Programm entfernt.' -ForegroundColor Green
if (-not $AuchSpielstand) { Write-Host "Spielstand wurde behalten: $Data" }
