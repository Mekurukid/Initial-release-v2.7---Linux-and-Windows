@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo Python 3 wurde nicht gefunden.
  pause
  exit /b 1
)
%PY% -I "%~dp0launcher.py" --diagnose
pause
