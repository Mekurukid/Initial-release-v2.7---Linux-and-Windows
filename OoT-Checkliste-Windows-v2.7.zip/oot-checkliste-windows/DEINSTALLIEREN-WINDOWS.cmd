@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0DEINSTALLIEREN-WINDOWS.ps1"
pause
