@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title OoT Sammel-Checklisten 2.7 - Windows

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY goto :nopython

%PY% -I "%~dp0launcher.py" %*
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo Die OoT-Checkliste konnte nicht vollstaendig gestartet werden.
  echo Fehlercode: %RC%
  echo.
  echo Falls oben eine Fehlermeldung steht, kannst du sie kopieren oder einen Screenshot machen.
  pause
)
exit /b %RC%

:nopython
echo.
echo Python 3 wurde nicht gefunden.
echo.
echo Fuer die Windows-App wird Python 3.8 oder neuer benoetigt.
echo Lade Python von https://www.python.org/downloads/windows/ herunter
ECHO und aktiviere bei der Installation "Add python.exe to PATH".
echo.
echo ALTERNATIVE OHNE PYTHON:
echo Doppelklicke auf DIREKTSTART.html. Diese Variante speichert den Fortschritt im Browser.
echo.
pause
exit /b 1
