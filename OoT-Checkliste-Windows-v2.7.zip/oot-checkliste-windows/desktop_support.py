#!/usr/bin/env python3
"""Windows desktop helpers for OoT Sammel-Checklisten 2.7."""
from __future__ import annotations
import os
import platform
from pathlib import Path
import subprocess
import sys
import tempfile
import webbrowser

EDITION='Windows Edition 2.7'
RUNTIME_FILES=('app.py','launcher.py','desktop_support.py','guide_reader.py','catalog.json','index.html','style.css','ui.js','windows-ui.js','icon.svg','placeholder.svg')

def local_appdata() -> Path:
    value=os.environ.get('LOCALAPPDATA')
    if value:
        return Path(value)
    return Path.home()/'AppData'/'Local'

def install_target() -> Path:
    return local_appdata()/'Programs'/'OoT-Sammel-Checklisten'

def log_directory() -> Path:
    path=local_appdata()/'OoT-Sammel-Checklisten'/'logs'
    path.mkdir(parents=True,exist_ok=True)
    return path

def system_summary() -> dict:
    return {
        'edition':EDITION,
        'system':f'{platform.system()} {platform.release()}',
        'desktop':'Windows Desktop',
        'session':'Desktop',
        'architecture':platform.machine() or 'unbekannt',
        'python':platform.python_version(),
        'windows':True,
    }

def open_browser(url: str) -> bool:
    if not url.startswith('http://127.0.0.1:'):
        raise ValueError('Es darf nur die lokale Checklisten-Adresse geoeffnet werden.')
    try:
        return bool(webbrowser.open_new_tab(url))
    except Exception:
        return False

def dialog(title: str, message: str, error: bool=False, report: Path | None=None) -> bool:
    text=message
    if report and report.exists():
        try:text=report.read_text(encoding='utf-8')
        except OSError:pass
    # Use a small PowerShell MessageBox when available; otherwise the console output remains visible.
    ps='powershell.exe'
    script=(
        "Add-Type -AssemblyName PresentationFramework;"
        "$icon="+('"Error"' if error else '"Information"')+";"
        "[System.Windows.MessageBox]::Show($env:OOT_DIALOG_TEXT,$env:OOT_DIALOG_TITLE,'OK',$icon) | Out-Null"
    )
    env=os.environ.copy();env['OOT_DIALOG_TEXT']=text[-12000:];env['OOT_DIALOG_TITLE']=title
    try:
        subprocess.Popen([ps,'-NoProfile','-NonInteractive','-Command',script],env=env,
                         stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return True
    except OSError:
        return False

def redact(text: str) -> str:
    import re
    text=re.sub(r'http://127\.0\.0\.1:\d+/[a-f0-9]{48}/','http://127.0.0.1:PORT/[SITZUNG]/',text)
    text=re.sub(r'\b[a-f0-9]{48}\b','[SITZUNG]',text)
    home=str(Path.home())
    if len(home)>2:text=text.replace(home,'~')
    return text

def diagnostic_text(app, directory: Path) -> tuple[str,bool]:
    info=system_summary();ok=True
    lines=['OOT WINDOWS STARTDIAGNOSE','========================',
           'App-Version: '+app.VERSION,'Edition: '+EDITION,
           'System: '+info['system'],'Architektur: '+info['architecture'],
           'Python: '+info['python'],'Python-Datei: '+sys.executable,
           'Programmordner: '+str(app.ROOT),'Datenordner: '+str(directory),'','Programmdateien:']
    for name in RUNTIME_FILES:
        exists=(app.ROOT/name).is_file();ok=ok and exists
        lines.append('  '+name+': '+('OK' if exists else 'FEHLT'))
    try:
        directory.mkdir(parents=True,exist_ok=True)
        fd,path=tempfile.mkstemp(prefix='.windows-test-',dir=str(directory));os.close(fd);os.unlink(path)
        lines.append('Schreibtest: OK')
    except OSError as exc:
        ok=False;lines.append('Schreibtest: FEHLER - '+str(exc))
    try:
        live=app.running(directory)
        lines.append('Laufende Version: '+(live[1] if live else 'keine'))
    except Exception as exc:
        lines.append('Laufende Version: Pruefung fehlgeschlagen - '+str(exc))
    lines.extend(['','Es werden keine Haekchen, Notizen oder Sitzungstoken in diese Diagnose geschrieben.',
                  'Die Anwendung benoetigt Python 3.8 oder neuer und einen aktuellen Webbrowser.',
                  'Empfohlen unter Windows: Python von python.org mit aktivierter Option "Add python.exe to PATH".'])
    return redact('\n'.join(lines)+'\n'),ok

def install_app(app) -> int:
    print('Unter Windows bitte INSTALLIEREN-WINDOWS.ps1 verwenden.')
    return 2
