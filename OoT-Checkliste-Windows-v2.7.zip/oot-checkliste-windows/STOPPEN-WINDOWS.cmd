@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY exit /b 1
%PY% -I "%~dp0launcher.py" --stop
if errorlevel 1 pause
