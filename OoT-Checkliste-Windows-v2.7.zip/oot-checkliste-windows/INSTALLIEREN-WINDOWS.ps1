param(
  [switch]$NoStart,
  [switch]$NoDownload
)
$ErrorActionPreference = 'Stop'
$Source = Split-Path -Parent $MyInvocation.MyCommand.Path
$LocalAppData = [Environment]::GetFolderPath('LocalApplicationData')
$Programs = Join-Path $LocalAppData 'Programs'
$Target = Join-Path $Programs 'OoT-Sammel-Checklisten'
$Data = Join-Path $LocalAppData 'OoT-Sammel-Checklisten\data'
$StartMenu = Join-Path ([Environment]::GetFolderPath('Programs')) 'OoT Sammel-Checklisten.lnk'

function Find-Python {
  if (Get-Command py.exe -ErrorAction SilentlyContinue) { return @('py.exe','-3') }
  if (Get-Command python.exe -ErrorAction SilentlyContinue) { return @('python.exe') }
  return $null
}

$Python = Find-Python
if (-not $Python) {
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show(
    "Python 3 wurde nicht gefunden.`n`nInstalliere Python 3.8 oder neuer von python.org und aktiviere 'Add python.exe to PATH'.`n`nDu kannst alternativ DIREKTSTART.html ohne Python verwenden.",
    'OoT Sammel-Checklisten', 'OK', 'Warning') | Out-Null
  exit 1
}

# Running app: ask the local server to shut down by calling the current installed launcher with --stop.
if (Test-Path (Join-Path $Target 'launcher.py')) {
  try {
    & $Python[0] @($Python[1..($Python.Count-1)]) -I (Join-Path $Target 'launcher.py') --stop | Out-Null
    Start-Sleep -Milliseconds 500
  } catch { }
}

New-Item -ItemType Directory -Force -Path $Programs | Out-Null
New-Item -ItemType Directory -Force -Path $Data | Out-Null

# Keep the user data outside the program directory. Updating the app never removes the save files.
$Backup = $null
if (Test-Path $Target) {
  $Backup = "$Target.backup-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
  Move-Item -LiteralPath $Target -Destination $Backup
}
try {
  New-Item -ItemType Directory -Force -Path $Target | Out-Null
  $Exclude = @('INSTALLIEREN-WINDOWS.ps1')
  Get-ChildItem -LiteralPath $Source -Force | Where-Object { $Exclude -notcontains $_.Name } | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $Target -Recurse -Force
  }
  Copy-Item -LiteralPath $MyInvocation.MyCommand.Path -Destination (Join-Path $Target 'INSTALLIEREN-WINDOWS.ps1') -Force

  # Desktop/Start-menu shortcut.
  $Shell = New-Object -ComObject WScript.Shell
  $Shortcut = $Shell.CreateShortcut($StartMenu)
  $Shortcut.TargetPath = Join-Path $Target 'STARTEN-WINDOWS.cmd'
  $Shortcut.WorkingDirectory = $Target
  $Shortcut.Description = 'Ocarina of Time Sammel-Checkliste'
  $Shortcut.Save()
} catch {
  if (Test-Path $Target) { Remove-Item -LiteralPath $Target -Recurse -Force }
  if ($Backup -and (Test-Path $Backup)) { Move-Item -LiteralPath $Backup -Destination $Target }
  throw
}

Write-Host ''
Write-Host 'OoT Sammel-Checklisten 2.7 wurde installiert.' -ForegroundColor Green
Write-Host "Programm: $Target"
Write-Host "Spielstand: $Data"
Write-Host 'Startmenue: OoT Sammel-Checklisten'
Write-Host 'Dein vorhandener Windows-Spielstand bleibt bei Updates erhalten.'

if (-not $NoStart) {
  $args = @()
  if ($NoDownload) { $args += '--no-download' }
  Start-Process -FilePath (Join-Path $Target 'STARTEN-WINDOWS.cmd') -ArgumentList $args -WorkingDirectory $Target
}
